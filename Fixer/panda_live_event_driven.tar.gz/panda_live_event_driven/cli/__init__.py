"""CLI display modules for PANDA LIVE."""
