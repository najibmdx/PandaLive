"""PANDA LIVE - Real-time memecoin situational awareness"""

__version__ = "1.0.0"
